var require = meteorInstall({"breakingdev.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// breakingdev.js                                                                            //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
                                                                                             //
devers = new Meteor.Collection("devers");                                                    // 2
volunteers = new Meteor.Collection("volunteers");                                            // 3
                                                                                             //
if (Meteor.isClient) {                                                                       // 8
  // counter starts at 0                                                                     //
  Session.setDefault('counter', 0);                                                          // 10
                                                                                             //
  Template.options.events({                                                                  // 13
    "click #infolink": function clickInfolink() {                                            // 14
      scrollFunction('#info');                                                               // 15
    },                                                                                       // 16
                                                                                             //
    "click #mainlink": function clickMainlink() {                                            // 18
      scrollFunction('#main');                                                               // 19
    }                                                                                        // 20
                                                                                             //
  });                                                                                        // 13
                                                                                             //
  Template.index.events({                                                                    // 26
                                                                                             //
    "click #dirlink": function clickDirlink() {                                              // 28
      scrollFunction('#dir');                                                                // 29
    },                                                                                       // 30
                                                                                             //
    "click #catlink": function clickCatlink() {                                              // 32
      scrollFunction('#cat');                                                                // 33
    },                                                                                       // 34
                                                                                             //
    "click #prizelink": function clickPrizelink() {                                          // 36
      scrollFunction('#prize');                                                              // 37
    },                                                                                       // 38
                                                                                             //
    "click #placelink": function clickPlacelink() {                                          // 40
      scrollFunction('#place');                                                              // 41
    },                                                                                       // 42
                                                                                             //
    "click #infolink": function clickInfolink() {                                            // 44
      scrollFunction('#info');                                                               // 45
    },                                                                                       // 46
                                                                                             //
    "click #challengelink": function clickChallengelink() {                                  // 48
      scrollFunction('#challenge');                                                          // 49
    },                                                                                       // 50
                                                                                             //
    "click #sponsorlink": function clickSponsorlink() {                                      // 52
      scrollFunction('#sponsor');                                                            // 53
    },                                                                                       // 54
                                                                                             //
    "click #signuplink": function clickSignuplink() {                                        // 56
      scrollFunction('#signup');                                                             // 57
    }                                                                                        // 58
                                                                                             //
  });                                                                                        // 26
                                                                                             //
  Template.devReg.events({                                                                   // 62
    'submit .addDevForm': function submitAddDevForm(event) {                                 // 63
                                                                                             //
      event.preventDefault();                                                                // 66
                                                                                             //
      var name = event.target.name.value;                                                    // 69
      var age = event.target.age.value;                                                      // 70
      var city = event.target.city.value;                                                    // 71
                                                                                             //
      devers.insert({                                                                        // 74
        name: name,                                                                          // 75
        age: age,                                                                            // 76
        city: city,                                                                          // 77
        createdAt: new Date() // current time                                                // 78
      });                                                                                    // 74
                                                                                             //
      // Clear form                                                                          //
      event.target.name.value = "";                                                          // 82
      event.target.mail.value = "";                                                          // 83
      event.target.subject.value = "";                                                       // 84
      event.target.data.value = "";                                                          // 85
    }                                                                                        // 87
                                                                                             //
  });                                                                                        // 62
                                                                                             //
  Template.contacts.events({                                                                 // 91
                                                                                             //
    'submit .contactoGeralForm': function submitContactoGeralForm(event) {                   // 93
                                                                                             //
      event.preventDefault();                                                                // 95
                                                                                             //
      var name = event.target.name.value;                                                    // 98
      var mail = event.target.mail.value;                                                    // 99
      var company = event.target.company.value;                                              // 100
      var data = event.target.data.value;                                                    // 101
                                                                                             //
      // In your client code: asynchronously send an email                                   //
      Meteor.call('sendEmail', 'breakingdev@neeti.tecnico.ulisboa.pt', mail, company, data);
                                                                                             //
      // Clear form                                                                          //
      event.target.name.value = "";                                                          // 112
      event.target.mail.value = "";                                                          // 113
      event.target.company.value = "";                                                       // 114
      event.target.data.value = "";                                                          // 115
    }                                                                                        // 117
                                                                                             //
  });                                                                                        // 91
                                                                                             //
  Template.volunteer.events({                                                                // 123
                                                                                             //
    'submit .voluntarioForm': function submitVoluntarioForm(event) {                         // 125
                                                                                             //
      event.preventDefault();                                                                // 127
                                                                                             //
      var name = event.target.name.value;                                                    // 130
      var mail = event.target.mail.value;                                                    // 131
      var phone = event.target.phone.value;                                                  // 132
      var age = event.target.age.value;                                                      // 133
      var company = event.target.company.value;                                              // 134
      var course = event.target.course.value;                                                // 135
                                                                                             //
      volunteers.insert({                                                                    // 138
        name: name,                                                                          // 139
        mail: mail,                                                                          // 140
        phone: phone,                                                                        // 141
        age: age,                                                                            // 142
        company: company,                                                                    // 143
        course: course,                                                                      // 144
        createdAt: new Date() // current time                                                // 145
      });                                                                                    // 138
                                                                                             //
      // Clear form                                                                          //
      event.target.name.value = "";                                                          // 149
      event.target.mail.value = "";                                                          // 150
      event.target.phone.value = "";                                                         // 151
      event.target.age.value = "";                                                           // 152
      event.target.company.value = "";                                                       // 153
      event.target.course.value = "";                                                        // 154
    }                                                                                        // 156
                                                                                             //
  });                                                                                        // 123
}                                                                                            // 161
                                                                                             //
if (Meteor.isServer) {                                                                       // 163
  Meteor.startup(function () {                                                               // 164
    // code to run on server at startup                                                      //
                                                                                             //
    //replace xxxxx and yyyyy with gmail username and password                               //
    process.env.MAIL_URL = "smtp://postmaster%40USER:PASSWORD@smtp.mailgun.org:587";         // 169
                                                                                             //
    Meteor.methods({                                                                         // 172
      sendEmail: function sendEmail(to, from, company, text) {                               // 173
        check([to, from, company, text], [String]);                                          // 174
                                                                                             //
        // Let other method calls from the same client start running,                        //
        // without waiting for the email sending to complete.                                //
        this.unblock();                                                                      // 178
                                                                                             //
        Email.send({                                                                         // 180
          to: to,                                                                            // 181
          from: from,                                                                        // 182
          subject: company,                                                                  // 183
          text: text                                                                         // 184
        });                                                                                  // 180
      }                                                                                      // 186
    });                                                                                      // 172
  });                                                                                        // 189
}                                                                                            // 190
                                                                                             //
var scrollFunction = function scrollFunction(idstring) {                                     // 192
  $('html, body').animate({                                                                  // 193
    scrollTop: $(idstring).offset().top                                                      // 194
  }, 1000);                                                                                  // 193
};                                                                                           // 196
                                                                                             //
// Iron Router                                                                               //
                                                                                             //
Router.route('/', function () {                                                              // 203
  this.render("index");                                                                      // 204
});                                                                                          // 205
                                                                                             //
Router.route('/contactos', function () {                                                     // 207
  this.render("contacts");                                                                   // 208
});                                                                                          // 209
                                                                                             //
Router.route('/inscricoes', function () {                                                    // 211
  this.render("insc");                                                                       // 212
});                                                                                          // 213
                                                                                             //
Router.route('/voluntarios', function () {                                                   // 215
  this.render("volunteer");                                                                  // 216
});                                                                                          // 217
///////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./breakingdev.js");
//# sourceMappingURL=app.js.map
